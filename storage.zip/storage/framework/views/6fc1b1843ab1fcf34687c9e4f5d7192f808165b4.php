<?php $__env->startSection('content'); ?>
    <section class="header-title">
        <div class="container-xl pt-5 pb-5">
            <h2 class="fw-bold pt-5 pb-5 text-uppercase">
                <?php echo e(App::getLocale() == 'en' ? $data['detail_job']->position_en : $data['detail_job']->position_kh); ?>

            </h2><br>
        </div>
    </section><br><br>
    <div class="container-xl p-5" style="background: #fff">
        <div class="row m-0">
            <div class="col-md-4 col-sm-12 text-center">
                <div class="p-5" style="border: 1px solid #8080802e;background: #80808012;">
                    <?php if($data['detail_job']->thumbnail == null): ?>
                        <img class="img-detail" src="<?php echo e($data['detail_job']->thumbnail_com); ?>" alt="">
                    <?php else: ?>
                        <img class="img-detail" src="<?php echo e($data['detail_job']->thumbnail); ?>" alt="">
                    <?php endif; ?>
                    <br><br>
                    <div class="cs-text">
                        <ul class="detail-list">
                            <li>
                                <a target="_blank" href="<?php echo e($data['detail_job']->external_url); ?>"
                                    class="site-link"><?php echo e($data['detail_job']->external_url); ?></a>
                            </li>
                        </ul>
                        <ul class="share-medea">
                            <li>
                                <a target="_blank" href="<?php echo e($data['detail_job']->facebook_url); ?>"
                                    data-original-title="facebook">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div><br>
                <div class="p-5 text-center" style="border: 1px solid #8080802e;background: #80808012;">
                    <h4 class="fw-bold" style="color: #f06c19 ">
                        <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                        <?php echo e(App::getLocale() == 'en' ? 'SAFETY INFORMATION' : 'ព័ត៌មានសុវត្ថិភាព'); ?>

                    </h4>
                    <strong>
                        <?php echo e(App::getLocale() == 'en' ? 'Only shortlisted applicants will be contacted within 03 working days' : 'មានតែបេក្ខជនដែលជាប់ក្នុងបញ្ជីសម្រាំងប៉ុណ្ណោះនឹងត្រូវបានទាក់ទងក្នុងរយៈពេល 03 ថ្ងៃធ្វើការ'); ?>

                    </strong>
                </div>
            </div>
            <div class="col-md-8 col-sm-12">
                <h4 class="fw-bold mt-lg-5 mt-2 color-dark-purple">
                    <?php echo e(App::getLocale() == 'en' ? $data['detail_job']->position_en : $data['detail_job']->position_kh); ?>

                </h4><br>
                <div class="row col-md-12 col-sm-12">
                    <div class="col-md-3 col-sm-12">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                        <span><?php echo e(App::getLocale() == 'en' ? 'Post Date' : 'ថ្ងៃប្រកាស'); ?>:</span>
                        <strong><?php echo e($data['detail_job']->start_date); ?></strong>

                    </div>
                    <div class="col-md-4 col-sm-12">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                        <span><?php echo e(App::getLocale() == 'en' ? 'Apply Before' : 'ដាក់ពាក្យមុនថ្ងៃ'); ?>:</span>
                        <strong><?php echo e($data['detail_job']->end_date); ?></strong>

                    </div>
                    <div class="col-md-3 col-sm-12">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                        <span><?php echo e(App::getLocale() == 'en' ? 'Location' : 'ទីតាំង'); ?>:</span>
                        <strong><?php echo e(App::getLocale() == 'en' ? $data['detail_job']->location_en : $data['detail_job']->location_kh); ?></strong>
                    </div>
                    <div class="col-md-2 col-sm-12">
                        <i class="fa fa-tasks" aria-hidden="true"></i>
                        <strong><?php echo e(App::getLocale() == 'en' ? $data['detail_job']->vacancy_en : $data['detail_job']->vacancy_kh); ?></strong>
                    </div>
                </div><br><br>
                <div class="row col-md-12 col-sm-12 p-5" style="border: 1px solid #e6e6e6;">
                    <div class="col-md-4 col-sm-12">
                        <span><?php echo e(App::getLocale() == 'en' ? 'Offered Salary' : 'ផ្តល់ប្រាក់ខែ'); ?></span><br>
                        <strong><?php echo e($data['detail_job']->offered_salary); ?></strong>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <span><?php echo e(App::getLocale() == 'en' ? 'Career Level' : 'កម្រិតអាជីព'); ?></span><br>
                        <strong><?php echo e(App::getLocale() == 'en' ? $data['detail_job']->career_level_en : $data['detail_job']->career_level_kh); ?></strong>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <span><?php echo e(App::getLocale() == 'en' ? 'Company Industry' : 'កម្រិតអាជីពក្រុមហ៊ុន'); ?></span><br>
                        <strong><?php echo e(App::getLocale() == 'en' ? $data['detail_job']->department_en : $data['detail_job']->department_kh); ?></strong>
                    </div>
                </div>
                <div class="row col-md-12 col-sm-12 p-5 mt-3" style="border: 1px solid #e6e6e6;">
                    <div class="col-md-4 col-sm-12">
                        <span><?php echo e(App::getLocale() == 'en' ? 'Qualification' : 'កម្រឹតវប្បធម៍'); ?></span><br>
                        <strong><?php echo e(App::getLocale() == 'en' ? $data['detail_job']->qualification_en : $data['detail_job']->qualification_kh); ?></strong>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <span><?php echo e(App::getLocale() == 'en' ? 'Hiring' : 'ស្វែងរក'); ?></span><br>
                        <strong><?php echo e($data['detail_job']->hiring); ?></strong>
                        <?php if($data['detail_job']->hiring != 1): ?>
                            <strong><?php echo e(App::getLocale() == 'en' ? 'Positions' : 'នាក់'); ?></strong>
                        <?php else: ?>
                            <strong><?php echo e(App::getLocale() == 'en' ? 'Position' : 'នាក់'); ?></strong>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4 col-sm-12">
                        <span><?php echo e(App::getLocale() == 'en' ? 'Language Skills' : 'ជំនាញ​ភាសា'); ?></span><br>
                        <strong>
                            <?php $__currentLoopData = $data['languageSkill']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </strong>
                    </div>
                </div>
                <div class="row col-md-12 col-sm-12 p-5 mt-3">
                    <?php
                    $str = '';
                    if (App::getLocale() == 'en') {
                        $article_editor = $data['detail_job']->description_en;
                    } else {
                        $article_editor = $data['detail_job']->description_kh;
                    }
                    $str = $str . $article_editor;
                    $str =
                        $str .
                        "</span>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            </p>";
                    echo $str;
                    ?>
                </div>
                <div class="row col-md-12 col-sm-12 pb-5">
                    <h4 class="fw-bold color-dark-purple">
                        <?php echo e(App::getLocale() == 'en' ? 'Related Jobs' : 'ការងារដែលពាក់ពន្ធ័'); ?>

                    </h4><br>
                    <?php $__currentLoopData = $data['related_job']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->company == $data['detail_job']->company): ?>
                            <div class="p-5 mb-5 categories-job" style="border-bottom: 1px solid #e6e6e6">
                                <a
                                    href="<?php echo e(url(App::getLocale() == 'en' ? 'en/articles/' . $value->id : 'articles/' . $value->id)); ?>">
                                    <p class="p-0 col-md-10 col-sm-10"><b>
                                            <?php echo e(App::getLocale() == 'en' ? $value->title_en . ' on' : $value->title_kh); ?></b>
                                        <span> <?php echo e($value->start_date); ?></span>
                                    </p>
                                    <p class="col-md-2 col-sm-2 m-0">
                                        <a href="<?php echo e(url(App::getLocale() == 'en' ? 'en/articles/' . $value->id : 'articles/' . $value->id)); ?>"
                                            class="vacancy-type">
                                            <?php echo e(App::getLocale() == 'en' ? $value->vacancy_type_en : $value->vacancy_type_kh); ?>

                                        </a>
                                    </p>
                                </a>
                            </div>
                        <?php else: ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mjqjob_website\resources\views/Cms/detail-job-post.blade.php ENDPATH**/ ?>