<?php $__env->startSection('content'); ?>
    <div style="background:#006790">
        <div class="container-xl pt-5 pb-5">
            <h2 style="color: #fff">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key == 1): ?>
                    <?php break; ?>;
                <?php else: ?>
                    <?php echo e(App::getLocale() == 'en' ? $value->company_en : $value->company_kh); ?>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h2>
    </div>
</div>
<div class="container-xl p-5" style="background: #fff">
    <div class="row m-0">
        <div class="col-md-4 col-sm-12 text-center">
            <div class="p-5" style="border: 1px solid #8080802e;background: #e0e0e029;">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key == 1): ?>
                    <?php break; ?>;
                <?php else: ?>
                    <?php if($value->thumbnail == null): ?>
                        <img class="img-detail" src="<?php echo e($value->thumbnail_com); ?>" alt="">
                    <?php else: ?>
                        <img class="img-detail" src="<?php echo e($value->thumbnail); ?>" alt="">
                    <?php endif; ?>
                    <br><br>
                    <span style="background: #e6e6e6;padding: 2px 9px;border-radius: 15px;">
                        <?php echo e(App::getLocale() == 'en' ? $value->deps_en : $value->deps_kh); ?>

                    </span>
                    <br><br>
                    <div class="cs-text">
                        <ul class="detail-list">
                            <li>
                                <a target="_blank" href="<?php echo e($value->external_url); ?>"
                                    class="site-link"><?php echo e($value->external_url); ?></a>
                            </li>
                        </ul>
                        <ul class="share-medea">
                            <li>
                                <a target="_blank" href="<?php echo e($value->facebook_url); ?>"
                                    value-original-title="facebook">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><br>
        <h4 class="fw-bold color-dark-purple"
            style="border: 1px solid #e4e4e4;
        padding: 12px;
        border-bottom: 0;
        margin-bottom: 0;">
            <?php echo e(App::getLocale() == 'en' ? 'Contact' : 'ទំនាក់ទំនង'); ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key == 1): ?>
                <?php break; ?>;
            <?php else: ?>
                <?php echo e(App::getLocale() == 'en' ? $value->company_en : $value->company_kh); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h4>
    <div class="p-5" style="border: 1px solid #8080802e;background: #e0e0e029;">
        <form method="post" action="" id="contactForm">
            <input type="hidden" name="_token" id="csrf" value="<?php echo e(Session::token()); ?>">
            <!--create token-->
            <div class="form-group">
                <input placeholder="<?php echo e(App::getLocale() == 'en' ? 'Name' : 'ឈ្មោះ'); ?>" type="text"
                    class="form-control" id="name" name='name' autocomplete="off" />
            </div>
            <div class="form-group">
                <input placeholder="<?php echo e(App::getLocale() == 'en' ? 'Email Address' : 'អាស័យ​ដ្ឋាន​អ៊ី​ម៉េ​ល'); ?>"
                    type="email" class="form-control" id="email" name='email' autocomplete="off" />
            </div>
            <div class="form-group">
                <input placeholder="<?php echo e(App::getLocale() == 'en' ? 'Subject' : 'ប្រធានបទ'); ?>" type="text"
                    class="form-control" id="subject" name='subject' autocomplete="off" />
            </div>
            <div class="form-group">
                <textarea placeholder="<?php echo e(App::getLocale() == 'en' ? 'Message' : 'សារ'); ?>" type="text" class="form-control"
                    id="message" name='message' autocomplete="off"></textarea>
            </div>
        </form>
        <button type="button" id="btnSave" class="read-more-news read-more btn btn-lg"
            style="min-width: 100px;
        justify-content: center;">
            <?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>

        </button>
    </div>
</div>
<div class="col-md-8 col-sm-12">
    <div class="row col-md-12 col-sm-12 pb-5">
        <h4 class="col-md-10 fw-bold color-dark-purple pb-3 ">
            <?php echo e(App::getLocale() == 'en' ? 'About' : 'អំពី'); ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key == 1): ?>
                <?php break; ?>;
            <?php else: ?>
                <?php echo e(App::getLocale() == 'en' ? $value->company_en : $value->company_kh); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h4>
    <p class="pb-3">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 1): ?>
            <?php break; ?>;
        <?php else: ?>
            <?php echo e(App::getLocale() == 'en' ? $value->description_en : $value->description_kh); ?>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
<h4 class="col-md-10 fw-bold color-dark-purple">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value->id == null): ?>
        <?php else: ?>
            <?php if($key == 1): ?>
            <?php break; ?>;
        <?php else: ?>
            <?php echo e(App::getLocale() == 'en' ? 'Jobs from' : 'ការងារពី'); ?>

            <?php echo e(App::getLocale() == 'en' ? $value->company_en : $value->company_kh); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h4>
<h4 class="col-md-2 fw-bold color-dark-purple text-center p-0">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($value->id == null): ?>
    <?php else: ?>
        <?php if($key == 1): ?>
        <?php break; ?>;
    <?php else: ?>
        <?php echo e(count($data)); ?> <br>

        <?php if(count($data) == 1): ?>
            <span> <?php echo e(App::getLocale() == 'en' ? 'Job' : 'ការងារ'); ?></span>
        <?php else: ?>
            <span> <?php echo e(App::getLocale() == 'en' ? 'Jobs' : 'ការងារ'); ?></span>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h4><br><br>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($value->id == null): ?>
<?php if($key == 1): ?>
    <h4 class="col-md-12 fw-bold color-dark-purple p-0">
        <?php echo e(App::getLocale() == 'en' ? 'No Jobs in this Company' : 'ក្រុមហ៊ុននេះមិនមានការងារធ្វើទេ។'); ?>

    </h4>
<?php break; ?>

<?php else: ?>
<?php endif; ?>
<?php else: ?>
<div class="p-3" style="border-bottom: 1px solid #e6e6e6">
<a href="/articles/<?php echo e($value->id); ?>">
    <p class="p-0 col-md-10 col-sm-10"><b>
            <?php echo e(App::getLocale() == 'en' ? $value->position_en : $value->position_kh); ?></b>
        <span> <?php echo e(App::getLocale() == 'en' ? 'on' : ''); ?></b>
            <?php
                $currentDateTime = new DateTime();
                $startDate = new DateTime($value->start_date);
                $dateDifference = $startDate->diff($currentDateTime);
                $daysDifference = $dateDifference->days;

                if ($daysDifference == 1) {
                    $dayDd = $daysDifference . (App::getLocale() == 'en' ? ' day ago' : ' ថ្ងៃ​មុន');
                    print "$dayDd";
                } else {
                    $dayDd = $daysDifference . (App::getLocale() == 'en' ? ' days ago' : ' ថ្ងៃ​មុន');
                    print "$dayDd";
                }
            ?>
        </span>
    </p>
    <p class="col-md-2 col-sm-2">
        <a href="/articles/<?php echo e($value->id); ?>"
            class="vacancy-type"><?php echo e(App::getLocale() == 'en' ? $value->vacancy_en : $value->vacancy_kh); ?></a>
    </p>
</a>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<nav aria-label="" class="d-flex justify-content-center">
<?php echo e($data->links('pagination::bootstrap-4')); ?>

</nav>
</div>
</div>
</div>
</div><br><br>
<script>
    function valueFil(val = null) {
        let name;
        let email;
        let subject;
        let message;
        if (val === null) {
            name = $('#name').val();
            email = $('#email').val();
            subject = $('#subject').val();
            message = $('#message').val();
        }
        if (val === 'clear') {
            $('#name').val('');
            $('#email').val('');
            $('#subject').val('');
            $('#message').val('');

        }

        return {
            'name': name,
            'email': email,
            'subject': subject,
            'message': message,

        };
    }
    var btnSave = true;
    $('#btnSave').on('click', () => {
        $.ajax({
            url: "<?php echo e(url('/admin/message-contact/contactSubmit')); ?>/",
            type: "POST",
            data: valueFil(),
            headers: {
                'X-CSRF-TOKEN': $("#csrf").val()
            },
            beforeSend: function() {
                $('#btnSave').text(
                    "<?php echo e(App::getLocale() == 'en' ? 'Sending...' : 'កំពុងផ្ញើ...'); ?>")
                $('#btnSave').attr("disabled", true);

            },
            success: function(response) {
                if (response.status == "error") {
                    valueFil('clear');
                    validationMgs(response);
                    $('#btnSave').text("<?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>");
                    $('#btnSave').removeAttr("disabled");
                } else {
                    valueFil('clear');
                    showMessage('success', 'Sent Successfully');
                    $('#btnSave').text("<?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>");
                    $('#btnSave').removeAttr("disabled");
                }
                btnSave = true;
                $('.btn-send-contact').text('<?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>');
            },
            error: function(e) {
                showMessage('Error Saving User', 'error');
            }
        });
    });

    function sweetToast(message, icon) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true,
        });

        Toast.fire({
            icon: icon,
            title: message,
        });
    }

    function validationMgs(response) {
        let msg = '';
        for (let x in response.result) {
            msg += response.result[x][0];
        }
        return sweetToast(msg, response.icon);
    }

    function showMessage(type, message) {
        Swal.fire({
            position: "top-end",
            icon: type,
            title: message,
            showConfirmButton: false,
            timer: 2000
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mjqjob_website\resources\views/Cms/search-job-company.blade.php ENDPATH**/ ?>