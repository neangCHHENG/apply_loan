<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="wrapper">
            <div class="thumbnail">
                <img src="<?php echo e(asset('FrontEnd/Image/background/bg-015.jpg')); ?>">
            </div>
            <div class="container-xl content-title" style="max-width: 1096px;">
                <div class=" p-0">
                    <h2 class="text-white titleMJQE" style="text-shadow: 2px 2px #45454575;">
                        <?php echo e(App::getLocale() == 'en' ? $data['category']->name_en : $data['category']->name_kh); ?>

                    </h2>
                </div>
            </div>
        </div>
    </section>
    <div class="container-xl p-5 bg-white single-category" style="max-width: 1096px;">
        <div class="row" style="justify-content: center;">
            <?php $__currentLoopData = $data['article']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6 cardv1 mb-3">
                    <div class="card border-1">
                        <a
                            href="<?php echo e(url(App::getLocale() == 'kh' ? 'articles/' . $value->slug_en : 'en/articles/' . $value->slug_en)); ?>">
                            <div class="card-header p-0" style="height: 315px;">
                                <?php if($value->thumbnail == null): ?>
                                    <img src="<?php echo e(asset('FrontEnd/Image/background/noimage.jpg')); ?>"
                                        class="card-img-top img-overlay">
                                <?php else: ?>
                                    <img src="<?php echo e(asset($value->thumbnail)); ?>" class="card-img-top img-overlay">
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <a style="text-align: center; padding:10px"
                                    href="<?php echo e(url(App::getLocale() == 'kh' ? 'articles/' . $value->slug_en : 'en/articles/' . $value->slug_en)); ?>"
                                    class="news-link">
                                    <span
                                        style="font-size: 12px"><?php echo e(\Carbon\Carbon::parse($value->schedule)->format('M d, Y')); ?></span>
                                    <h4><?php echo e(Str::limit(App::getLocale() == 'en' ? $value->title_en : $value->title_kh, 60)); ?>

                                    </h4>
                                    <p><?php echo e(Str::limit(App::getLocale() == 'en' ? $value->introduction_en : $value->introduction_kh, 70)); ?>

                                    </p>
                                </a>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <nav aria-label="" class="d-flex justify-content-center">
            <?php echo e($data['article']->links('pagination::bootstrap-4')); ?>

        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ais_ccv_website\resources\views/Cms/single-category.blade.php ENDPATH**/ ?>