<?php $__env->startSection('content'); ?>
    <section class="mb-0 content-header">
        <div class="wrapper" style="height: 56vh">
            <div class="thumbnail">
                <img src="<?php echo e(asset('FrontEnd/Image/background/bg-015.jpg')); ?>">
            </div>
            <div class="col-md-5 col-sm-12 content-title" style="margin-bottom: auto">
                <div class="container-xl p-0 text-center">
                    <h2 class="text-white titleMJQE" style="text-shadow: 2px 2px #45454575;">
                        <?php echo e(App::getLocale() == 'en' ? 'PAGE NOT FOUND' : 'រកមិនឃើញទំព័រ'); ?>

                    </h2>
                    <form class="menu-search my-4" action="<?php echo e(url(App::getLocale() == 'kh' ? 'search' : 'en/search')); ?>"
                        method="GET">
                        <input class="input-search" type="search" name="search" id="search"
                            placeholder="<?php echo e(App::getLocale() == 'en' ? 'Search' : 'ស្វែងរក'); ?>">
                        &nbsp;<button id="btn-search" type="submit"
                            class="btn btn-sm btn-general btn-secondary-contained"><?php echo e(App::getLocale() == 'en' ? 'Search' : 'ស្វែងរក'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ais_ccv_website\resources\views/Cms/page-error.blade.php ENDPATH**/ ?>