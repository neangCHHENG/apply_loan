<?php $__env->startSection('content'); ?>
    <section class="home">
        <?php $__currentLoopData = $data['slide']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 1): ?>
            <?php break; ?>
        <?php endif; ?>
        <div class="p-5 home" style='background-image: url("<?php echo e($value->thumbnail); ?>");'>
            <div class="container-xl" style="position: relative">
                <form action="<?php echo e(url(App::getLocale() == 'en' ? 'en/search' : 'search')); ?>" method="GET">
                    <div class="search-form-group">
                        <div class="search-form-item">
                            <i class="fas fa-search"></i>
                            <input type="text" class="form-control" id="title" name='title' autocomplete="off"
                                placeholder="<?php echo e(App::getLocale() == 'en' ? 'Job title, Keywords...' : 'ស្វែងរកចំណងជើង...'); ?>" />
                        </div>
                        <div class="search-form-item">
                            <i class="fa fa-list"></i>
                            <select class="form-control select2" id="specialism" name='specialism'>
                                <option selected>All Specialisms</option>
                            </select>
                        </div>
                        <div class="search-form-item">
                            <i class="fa fa-map-marker-alt"></i>
                            <select class="form-control select2" id="locations" name='locations'>
                                <option>All Locations</option>
                            </select>
                        </div>
                        <div class="search-form-item">
                            <div class="search-btn ">
                                <button type="submit" class="form-control cs-bgcolor"
                                    name="cs_"><?php echo e(App::getLocale() == 'en' ? 'Find Job' : 'ស្វែងរកការងារ'); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<section class="container-xl p-4">
    <h3><?php echo e(App::getLocale() == 'en' ? 'Browse Jobs by Categories' : 'ស្វែងរកការងារតាមប្រភេទផ្នែក'); ?></h3>
    <div class="row">
        <?php $__currentLoopData = $data['department']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="card p-5 categories-job mb-5" style="flex-direction: row">
                    <div class="col-sm-4 border-0">
                        <img src="<?php echo e($value->thumbnail); ?>" alt="slide">
                    </div>
                    <div class="col-sm-8 p-0 pt-3">
                        <b><?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?></b><br>
                        <span>
                            <?php if($value->job_count == 1): ?>
                                <?php echo e($value->job_count); ?> <?php echo e(App::getLocale() == 'en' ? 'job available' : 'ការងារ'); ?>

                            <?php else: ?>
                                <?php echo e($value->job_count); ?> <?php echo e(App::getLocale() == 'en' ? 'jobs available' : 'ការងារ'); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<section class="container-xl p-4 mt-lg-5">
    <div class="row">
        <h3><?php echo e(App::getLocale() == 'en' ? 'TOP UP YOUR JOB' : 'បញ្ចូលការងាររបស់អ្នក'); ?></h3>
        <span><?php echo e(App::getLocale() == 'en' ? 'Most featured jobs listed' : 'ការងារពិសេសបំផុតដែលបានរាយបញ្ជី'); ?></span><br><br>
        <a class="pb-3 text-right" style="padding-right: 3rem"
            href="<?php echo e(url(App::getLocale() == 'en' ? 'en/find-jobs/' : 'find-jobs/')); ?>">
            <?php echo e(App::getLocale() == 'en' ? 'More Jobs...' : 'ការងារច្រើនទៀត...'); ?>

        </a>
    </div>
    <div class="row">
        <?php $__currentLoopData = $data['jobList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-sm-12 mb-5">
                <div class="card categories-job w-100 " style="border: 1px solid #e8e8e8; ">
                    <div class="row p-5">
                        <div class="col-md-3 col-sm-3 col-12">

                            <div class="thumbnial-wrapper"
                                style="border: 1px solid #dadada; padding: 5px; border-radius: 4px; margin: 0 auto">
                                <div class="ribbon">
                                    <?php if($value->urgent == 1): ?>
                                        <span><?php echo e(App::getLocale() == 'en' ? 'Urgent' : 'បន្ទាន់'); ?></span>
                                    <?php else: ?>
                                    <?php endif; ?>
                                </div>

                                <a
                                    href="<?php echo e(url(App::getLocale() == 'en' ? '/en/articles/' . $value->id : '/articles/' . $value->id)); ?>">
                                    <?php if($value->thumbnail == null): ?>
                                        <div class="thumbnial-inner img1by1">
                                            <img class="img-fluid" src="<?php echo e($value->thumbnail_com); ?>" alt="">
                                        </div>
                                    <?php else: ?>
                                        <div class="thumbnial-inner img1by1">
                                            <img class="img-fluid" src="<?php echo e($value->thumbnail); ?>" alt="">
                                        </div>
                                    <?php endif; ?>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mt-sm-0 col-8 mt-5 p-xs-0">
                            <a class="caption-job"
                                href="<?php echo e(url(App::getLocale() == 'en' ? '/en/articles/' . $value->id : '/articles/' . $value->id)); ?>">
                                <p>
                                    <b><?php echo e(App::getLocale() == 'en' ? $value->position_en : $value->position_kh); ?></b>
                                </p>
                                <span>
                                    <?php echo e(App::getLocale() == 'en' ? $value->company_en : $value->company_kh); ?>,
                                    <?php echo e(App::getLocale() == 'en' ? $value->location_en : $value->location_kh); ?>

                                </span>
                                <br>
                                <span class="vacancy-type">
                                    <?php echo e(App::getLocale() == 'en' ? $value->vacancy_en : $value->vacancy_kh); ?>

                                </span>

                            </a>
                        </div>
                        <div class="col-md-3 col-sm-3 col-4 mt-sm-0 mt-5 text-center p-xs-0">
                            <i class="fa fa-heart" aria-hidden="true"></i><br>
                            <b class="pt-5 fz-xs-12" style="display: inline-block;color:#e00808">
                                <?php echo e($value->offered_salary); ?></b>
                        </div>
                    </div>
                </div>
            </div><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<section class="container-xl p-5 mt-lg-5">
    <h3><?php echo e(App::getLocale() == 'en' ? 'Our Company' : 'ក្រុមហ៊ុនរបស់យើង'); ?></h3><br>
    
    <?php
    $ourCompany = '';
    foreach ($menuFooterItems as $key => $value) {
        if ($value->key == 'ourCompany') {
            $ourCompany = $value->image;
        }
    }
    ?>
    <img class="w-100" src="<?php echo e($ourCompany); ?>" alt="ourCompany.png">
    
</section>

<section class="container-xl mt-lg-5 p-5">
    <h3><?php echo e(App::getLocale() == 'en' ? 'Our Benefits' : 'អត្ថប្រយោជន៍របស់យើង'); ?></h3><br>
    <div class="row">
        <?php $__currentLoopData = $data['benefit']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6 mt-3">
                <div class="card w-100 h-100 categories-job" style="border: 1px solid #e8e8e8;">
                    <div class="row p-3 ">
                        <a class="caption-job px-4">
                            <h3 style="color: #006790 !important; text-align:center"><?php echo e($key + 1); ?>.<br /> <b
                                    style="font-size: 15px;color:black">
                                    <?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?>

                                </b>
                            </h3>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><br><br>
<script>
    $(document).ready(function() {
        getSpecialismList();
        getLocationList();
    });

    window.onload = function() {
        let popup = $('#popupValue').val();
        if (popup) {
            setTimeout(function() {
                $("#popup").addClass("active");
            }, 10);
        }
    }

    function closePopup() {
        $("#popup").removeClass("active");
    }

    function getSpecialismList() {
        $.ajax({
            url: "<?php echo e(url('/admin/searchSpecialism/getSpecialismList')); ?>",
            type: "GET",

            success: function(response) {
                if (response.result == "error") {
                    sweetToast(response.msg, response.result);
                    return;
                }
                var typeStr =
                    "<option><span>All Specialisms </span></option>";

                for (var i = 0; i < response.data.length; i++) {
                    typeStr +=
                        '<option value="' +
                        response.data[i].id +
                        '">' +
                        response.data[i].title_kh +
                        "-" +
                        response.data[i].title_en +
                        "</option>";
                }
                $("#specialism").html(typeStr);
            },
            error: function(e) {
                if (e.status == 401) {
                    //unauthenticate not login
                    Msg("Login is Required", "error");
                }
            },
        });
    }

    function getLocationList() {
        $.ajax({
                url: "<?php echo e(url('/admin/searchSpecialism/getLocationList')); ?>",
                type: "GET",

                success: function(response) {
                    if (response.result == "error") {
                        sweetToast(response.msg, response.result);
                        return;
                    }
                    var typeStr = "<option><span>All Locations</span></option>";
                    response.data[i].title_kh +
                        "-" +
                        response.data[i].title_en +
                        "</option>";
                }
                $("#locations").html(typeStr);
            },
            error: function(e) {
                if (e.status == 401) {
                    //unauthenticate not login
                    Msg("Login is Required", "error");
                }
            },
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mjqjob_website\resources\views/Cms/home.blade.php ENDPATH**/ ?>