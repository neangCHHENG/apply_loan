<?php $__env->startSection('content'); ?>
    <section class="header-title">
        <div class="container-xl pt-5 pb-5">
            <h2 class="fw-bold text-center pt-5 pb-5">
                <?php echo e(App::getLocale() == 'en' ? 'FIND COMPANY' : 'ស្វែងរកក្រុមហ៊ុន'); ?>

            </h2><br>
        </div>
    </section>
    <section class="container-xl p-4 mt-lg-5">
        <h3><?php echo e(App::getLocale() == 'en' ? 'TOP UP YOUR JOB' : 'បញ្ចូលការងាររបស់អ្នក'); ?></h3>
        <span><?php echo e(App::getLocale() == 'en' ? 'Most featured jobs listed' : 'ការងារពិសេសបំផុតដែលបានរាយបញ្ជី'); ?></span><br><br>
        <div class="row">
            <div class="col-md-4 col-sm-12 find-job">
                <form action="<?php echo e(url(App::getLocale() == 'en' ? 'en/search' : 'search')); ?>" method="GET">
                    <div class="p-5" style="background-color: #fff; display:inline-block">
                        <div class="col-md-12 col-sm-12 m-0 p-0">
                            <div class="form-group">
                                <input type="text" class="form-control" id="title" name='title' autocomplete="off"
                                    placeholder="<?php echo e(App::getLocale() == 'en' ? 'Job title, Keywords...' : 'ស្វែងរកចំណងជើង...'); ?>" />
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 m-0 p-0">
                            <div class="form-group">
                                <select class="form-control select2" id="specialism" name='specialism'>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 m-0 p-0">
                            <div class="form-group">
                                <select class="form-control select2" id="locations" name='locations'>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 m-0 p-0">
                            <div class="form-group">
                                <select class="form-control select2" id="vacancy_type" name='vacancy_type'>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 m-0 p-0">
                            <div class="form-group">
                                <div class="search-btn">
                                    <input type="submit" class="form-control cs-bgcolor" name="cs_"
                                        value="<?php echo e(App::getLocale() == 'en' ? 'Find Job' : 'ស្វែងរកការងារ'); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-8 col-sm-12">
                <?php $__currentLoopData = $data['companyList']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row p-5 categories-job" style="border: 1px solid #e8e8e8;">
                        <div class="col-md-3 col-sm-12">
                            <div class="ribbon"><span><?php echo e(App::getLocale() == 'en' ? 'Company' : 'ក្រុមហ៊ុន'); ?></span>
                            </div>
                            <a
                                href="<?php echo e(url(App::getLocale() == 'en' ? 'en/employer/' . $value->id : 'employer/' . $value->id)); ?>">
                                <img class="img-thumbnail" src="<?php echo e($value->thumbnail); ?>" alt="">
                            </a>

                        </div>
                        <div class="col-md-6 col-sm-12 mt-3">
                            <a class="caption-job"
                                href="<?php echo e(url(App::getLocale() == 'en' ? 'en/employer/' . $value->id : 'employer/' . $value->id)); ?>">
                                <span><?php echo e(App::getLocale() == 'en' ? $value->department_en : $value->department_kh); ?></span>
                                <p style="padding: 5px 0">
                                    <b><?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?></b>
                                </p>
                            </a>
                            <span><a href="<?php echo e($value->external_url); ?>"><?php echo e($value->external_url); ?></a></span>
                        </div>
                        <div class="col-md-3 col-sm-12 mt-5 text-right">
                            <span class="count-job">
                                <?php if($value->job_count == 1): ?>
                                    <?php echo e($value->job_count); ?> <?php echo e(App::getLocale() == 'en' ? 'job available' : 'ការងារ'); ?>

                                <?php else: ?>
                                    <?php echo e($value->job_count); ?> <?php echo e(App::getLocale() == 'en' ? 'jobs available' : 'ការងារ'); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                    </div><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <nav aria-label="" class="d-flex justify-content-center">
            <?php echo e($data['companyList']->links('pagination::bootstrap-4')); ?>

        </nav>

    </section>
    <br><br>
    <script>
        $(document).ready(function() {
            getSpecialismList();
            getLocationList();
            getVacancytypeList();
        });

        function getLocationList() {
            $.ajax({
                url: "<?php echo e(url('/admin/searchSpecialism/getLocationList')); ?>",
                type: "GET",

                success: function(response) {
                    if (response.result == "error") {
                        sweetToast(response.msg, response.result);
                        return;
                    }
                    var typeStr = "<option><span>Select location</span></option>";
                    for (var i = 0; i < response.data.length; i++) {
                        typeStr +=
                            '<option value="' +
                            response.data[i].id +
                            '">' +
                            response.data[i].title_kh +
                            "-" +
                            response.data[i].title_en +
                            "</option>";
                    }
                    $("#locations").html(typeStr);
                },
                error: function(e) {
                    if (e.status == 401) {
                        //unauthenticate not login
                        Msg("Login is Required", "error");
                    }
                },
            });
        }

        function getSpecialismList() {
            $.ajax({
                url: "<?php echo e(url('/admin/searchSpecialism/getSpecialismList')); ?>",
                type: "GET",
                success: function(response) {
                    if (response.result == "error") {
                        sweetToast(response.msg, response.result);
                        return;
                    }
                    var typeStr = "<option><span>Select specialisms</span></option>";
                    for (var i = 0; i < response.data.length; i++) {
                        typeStr +=
                            '<option value="' +
                            response.data[i].id +
                            '">' +
                            response.data[i].title_kh +
                            "-" +
                            response.data[i].title_en +
                            "</option>";
                    }
                    $("#specialism").html(typeStr);
                },
                error: function(e) {
                    if (e.status == 401) {
                        //unauthenticate not login
                        Msg("Login is Required", "error");
                    }
                },
            });
        }

        function getVacancytypeList() {
            $.ajax({
                url: "<?php echo e(url('/admin/searchVacancytype/getVacancytypeList')); ?>",
                type: "GET",
                success: function(response) {
                    if (response.result == "error") {
                        sweetToast(response.msg, response.result);
                        return;
                    }
                    var typeStr = "<option><span>Select vacancy type</span></option>";
                    for (var i = 0; i < response.data.length; i++) {
                        typeStr +=
                            '<option value="' +
                            response.data[i].id +
                            '">' +
                            response.data[i].title_kh +
                            "-" +
                            response.data[i].title_en +
                            "</option>";
                    }
                    $("#vacancy_type").html(typeStr);
                },
                error: function(e) {
                    if (e.status == 401) {
                        //unauthenticate not login
                        Msg("Login is Required", "error");
                    }
                },
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mjqjob_website\resources\views/Cms/company-list.blade.php ENDPATH**/ ?>