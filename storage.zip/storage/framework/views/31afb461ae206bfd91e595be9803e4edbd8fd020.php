<?php $__env->startSection('content'); ?>
    <section class="header-title">
        <div class="container-xl pt-5 pb-5">
            <h2 class="fw-bold pt-5 pb-5">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key == 1): ?>
                    <?php break; ?>;
                <?php else: ?>
                    <?php echo e(App::getLocale() == 'en' ? $value->company_en : $value->company_kh); ?>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h2><br>
    </div>
</section><br><br>

<div class="container-xl p-5" style="background: #fff">
    <div class="row m-0">
        <div class="col-md-4 col-sm-12 text-center">
            <div class="p-5" style="border: 1px solid #8080802e;background: #e0e0e029;">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key == 1): ?>
                    <?php break; ?>;
                <?php else: ?>
                    <?php if($value->thumbnail_com != null): ?>
                        <img class="img-detail" src="<?php echo e($value->thumbnail_com); ?>" alt="">
                    <?php else: ?>
                        <img class="img-detail" src="<?php echo e($value->thumbnail); ?>" alt="">
                    <?php endif; ?>
                    <br><br>
                    <span style="background: #e6e6e6;padding: 2px 9px;border-radius: 15px;">
                        <?php echo e(App::getLocale() == 'en' ? $value->deps_en : $value->deps_kh); ?>

                    </span>
                    <br><br>
                    <div class="cs-text">
                        <ul class="detail-list">
                            <li>
                                <a target="_blank" href="<?php echo e($value->external_url); ?>"
                                    class="site-link"><?php echo e($value->external_url); ?></a>
                            </li>
                        </ul>
                        <ul class="share-medea">
                            <li>
                                <a target="_blank" href="<?php echo e($value->facebook_url); ?>"
                                    value-original-title="facebook">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><br>
        <h4 class="fw-bold color-dark-purple"
            style="border: 1px solid #e4e4e4;
        padding: 12px;
        border-bottom: 0;
        margin-bottom: 0;">
            <?php echo e(App::getLocale() == 'en' ? 'Contact' : 'ទំនាក់ទំនង'); ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key == 1): ?>
                <?php break; ?>;
            <?php else: ?>
                <?php echo e(App::getLocale() == 'en' ? $value->company_en : $value->company_kh); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h4>
    <div class="p-5" style="border: 1px solid #8080802e;background: #e0e0e029;">
        <form method="post" action="" id="contactForm" enctype="multipart/form-data">
            <input type="hidden" name="_token" id="csrf" value="<?php echo e(Session::token()); ?>">
            <!--create token-->
            <div class="form-group">
                <input placeholder="<?php echo e(App::getLocale() == 'en' ? 'Name' : 'ឈ្មោះ'); ?>" type="text"
                    class="form-control" id="Cont_name" name='name' autocomplete="off" />
            </div>
            <div class="form-group">
                <input placeholder="<?php echo e(App::getLocale() == 'en' ? 'Email Address' : 'អាស័យ​ដ្ឋាន​អ៊ី​ម៉េ​ល'); ?>"
                    type="email" class="form-control" id="Cont_email" name='email' autocomplete="off" />
            </div>
            <div class="form-group">
                <input placeholder="<?php echo e(App::getLocale() == 'en' ? 'Subject' : 'ប្រធានបទ'); ?>" type="text"
                    class="form-control" id="Cont_subject" name='subject' autocomplete="off" />
            </div>
            <div class="form-group">
                <textarea placeholder="<?php echo e(App::getLocale() == 'en' ? 'Message' : 'សារ'); ?>" type="text" class="form-control"
                    id="Cont_message" name='message' autocomplete="off"></textarea>
            </div>
            <div class="form-group">
                <span class="input-group-btn">

                    <i class="fa fa-picture-o"></i> Select your profile
                    <input id="Cont_thumbnail" type="file" name="thumbnail" accept="image/*">
                </span>
            </div>
            <div class="form-group">
                <span class="input-group-btn">
                    <i class="fa fa-file"></i> Select your cv
                    <input id="Cont_fileCv" type="file" name="fileCv" accept="pdf/*">
                </span>

            </div>
        </form>
        <button type="button" id="btnSaveCont" class="read-more-news read-more btn btn-lg"
            style="min-width: 100px; justify-content: center;">
            <?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>

        </button>
    </div>
</div>
<div class="col-md-8 col-sm-12">
    <div class="row col-md-12 col-sm-12 pb-5">
        <h4 class="col-md-10 fw-bold color-dark-purple pb-3 ">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key == 1): ?>
                <?php break; ?>;
            <?php else: ?>
                <?php echo e(App::getLocale() == 'en' ? 'About ' . $value->company_en : 'អំពី ' . $value->company_kh); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </h4>
    <p class="pb-3">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key == 1): ?>
            <?php break; ?>;
        <?php else: ?>
            <?php echo e(App::getLocale() == 'en' ? $value->description_en : $value->description_kh); ?>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
<h4 class="col-md-10 fw-bold color-dark-purple">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value->id == null): ?>
        <?php else: ?>
            <?php if($key == 1): ?>
            <?php break; ?>;
        <?php else: ?>
            <?php echo e(App::getLocale() == 'en' ? 'Jobs from ' . $value->company_en : 'ការងារពី ' . $value->company_kh); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h4>
<h4 class="col-md-2 fw-bold color-dark-purple text-center p-0">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($value->id == null): ?>
    <?php else: ?>
        <?php if($key == 1): ?>
        <?php break; ?>;
    <?php else: ?>
        <?php echo e(count($data)); ?> <br>

        <?php if(count($data) == 1): ?>
            <span> <?php echo e(App::getLocale() == 'en' ? 'Job' : 'ការងារ'); ?></span>
        <?php else: ?>
            <span> <?php echo e(App::getLocale() == 'en' ? 'Jobs' : 'ការងារ'); ?></span>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h4><br><br>

</div>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($value->id == null): ?>
<?php if($key == 1): ?>
<h4 class="col-md-12 fw-bold color-dark-purple p-0">
    <?php echo e(App::getLocale() == 'en' ? 'No Jobs in this Company' : 'ក្រុមហ៊ុននេះមិនមានការងារធ្វើទេ។'); ?>

</h4>
<?php break; ?>

<?php else: ?>
<?php endif; ?>
<?php else: ?>
<div class="row p-5 w-100 categories-job" style="border: 1px solid #e8e8e8;">
<div class="col-md-3 col-sm-12">
<div class="ribbon">
    <?php if($value->urgent == 1): ?>
        <span><?php echo e(App::getLocale() == 'en' ? 'Urgent' : 'បន្ទាន់'); ?></span>
    <?php else: ?>
    <?php endif; ?>
</div>
<a
    href="<?php echo e(url(App::getLocale() == 'en' ? 'en/articles/' . $value->id : 'articles/' . $value->id)); ?>">
    <?php if($value->thumbnail != null): ?>
        <img class="img-thumbnail" src="<?php echo e($value->thumbnail); ?>" alt="">
    <?php else: ?>
        <img class="img-thumbnail" src="<?php echo e($value->thumbnail_com); ?>" alt="">
    <?php endif; ?>
</a>
</div>
<div class="col-md-7 col-sm-12">
<a class="caption-job"
    href="<?php echo e(url(App::getLocale() == 'en' ? 'en/articles/' . $value->id : 'articles/' . $value->id)); ?>">
    <p>
        <b><?php echo e(App::getLocale() == 'en' ? $value->position_en : $value->position_kh); ?></b>
    </p>
    <span>
        <?php echo e(App::getLocale() == 'en' ? $value->deps_en . ', ' . $value->company_en : $value->deps_kh . ', ' . $value->company_kh); ?>

    </span>
    <br>
    <span><?php echo e(App::getLocale() == 'en' ? $value->locations_en . ', on' : $value->locations_kh . ', '); ?></b>
        <?php
            $currentDateTime = new DateTime();
            $startDate = new DateTime($value->start_date);
            $dateDifference = $startDate->diff($currentDateTime);
            $daysDifference = $dateDifference->days;

            if ($daysDifference == 1) {
                $dayDd = $daysDifference . (App::getLocale() == 'en' ? ' day ago' : ' ថ្ងៃ​មុន');
                print "$dayDd";
            } else {
                $dayDd = $daysDifference . (App::getLocale() == 'en' ? ' days ago' : ' ថ្ងៃ​មុន');
                print "$dayDd";
            }
        ?>
    </span><br>
    <span class="vacancy-type">
        <?php echo e(App::getLocale() == 'en' ? $value->vacancy_en : $value->vacancy_kh); ?>

    </span>
</a>
</div>
<div class="col-md-2 col-sm-12 text-center">
<i class="fa fa-heart" aria-hidden="true"></i><br>
<b class="pt-5" style="display: inline-block;color:#e00808">
    <?php echo e($value->offered_salary); ?></b>
</div>
</div>
<br>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<nav aria-label="" class="d-flex justify-content-center">
<?php echo e($data->links('pagination::bootstrap-4')); ?>

</nav>
</div>
</div>
</div>
</div><br><br>
<script>
    function valueFilContSub(val = null) {
        let name;
        let email;
        let subject;
        let message;
        let thumbnail;
        let fileCv;
        if (val === null) {
            name = $('#Cont_name').val();
            email = $('#Cont_email').val();
            subject = $('#Cont_subject').val();
            message = $('#Cont_message').val();
            thumbnail = $('#Cont_thumbnail')[0].files[0];
            fileCv = $('#Cont_fileCv')[0].files[0];
        }
        if (val === 'clear') {
            $('#Cont_name').val('');
            $('#Cont_email').val('');
            $('#Cont_subject').val('');
            $('#Cont_message').val('');
            $('#Cont_thumbnail').val('');
            $('#Cont_fileCv').val('');

        }

        return {
            'name': name,
            'email': email,
            'subject': subject,
            'message': message,
            'thumbnail': thumbnail,
            'fileCv': fileCv,

        };
    }
    var btnSaveCont = true;
    $('#btnSaveCont').on('click', () => {
        let formData = new FormData();
        formData.append("name", $('#Cont_name').val());
        formData.append("email", $('#Cont_email').val());
        formData.append("subject", $('#Cont_subject').val());
        formData.append("message", $('#Cont_message').val());
        formData.append("thumbnail_form", $('#Cont_thumbnail')[0].files[0]);
        formData.append("fileCv_form", $('#Cont_fileCv')[0].files[0]);

        $.ajax({
            url: "<?php echo e(url('/admin/message-contact/contactSubmit')); ?>/",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            headers: {
                'X-CSRF-TOKEN': $("#csrf").val()
            },
            beforeSend: function() {
                $('#btnSaveCont').text(
                    "<?php echo e(App::getLocale() == 'en' ? 'Sending...' : 'កំពុងផ្ញើ...'); ?>")
                $('#btnSaveCont').attr("disabled", true);

            },
            success: function(response) {
                if (response.status == "error") {
                    valueFilContSub('clear');
                    validationMgs(response);
                    $('#btnSaveCont').text("<?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>");
                    $('#btnSaveCont').removeAttr("disabled");
                } else {
                    valueFilContSub('clear');
                    showMessage('success', 'Sent Successfully');
                    $('#btnSaveCont').text("<?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>");
                    $('#btnSaveCont').removeAttr("disabled");
                }
                btnSaveCont = true;
                $('.btn-send-contact').text('<?php echo e(App::getLocale() == 'en' ? 'Send' : 'ផ្ញើ'); ?>');
            },
            error: function(e) {
                showMessage('Error Saving User', 'error');
            }
        });
    });

    function sweetToast(message, icon) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true,
        });

        Toast.fire({
            icon: icon,
            title: message,
        });
    }

    function validationMgs(response) {
        let msg = '';
        for (let x in response.result) {
            msg += response.result[x][0];
        }
        return sweetToast(msg, response.icon);
    }

    function showMessage(type, message) {
        Swal.fire({
            position: "top-end",
            icon: type,
            title: message,
            showConfirmButton: false,
            timer: 2000
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mjqjob_website\resources\views/Cms/find-job-company.blade.php ENDPATH**/ ?>