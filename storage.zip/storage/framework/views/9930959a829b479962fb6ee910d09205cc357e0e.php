<style>
    .content-space {
        display: none;
    }
</style>
<div class="top-nav">
    <!-- 01 -->
    <div class="first-topnav container-xl">
        <div class="row">

            <?php
            $str = "<ul class='nav'>";
            foreach ($topMenu as $i => $item) {
                $aClass = '';
                $aDropdown = '';
                $externalLink = '';
                $slug = '';
                $hasChild = $item->right - $item->left > 1;
                $hasExternalUrl = $item->link != null;
                $changeLanguage = $item->menu_type == 'change_language';
                $menuName = App::getLocale() == 'en' ? $item->menu_en : $item->menu_kh;
                $menuSlug = App::getLocale() == 'en' ? $item->slug : $item->slug;
                $urlEn = url('en/' . $slugLanguage);
                $str = $str . "<li class='nav-item'>";
                if ($slugLanguage == $menuName || $slugLanguage == $menuSlug) {
                    $menuActive = 'active';
                } elseif (($slugLanguage == '/' || $slugLanguage == '/en') && $item->menu_type == 'main_page') {
                    // if it's home
                    $menuActive = 'active';
                } else {
                    $menuActive = '';
                }
                $str = $str . "<li class='nav-item dropdown " . $menuActive . " '>";
                if ($hasChild) {
                    $aClass = 'dropdown-toggle';
                    $aDropdown = "id='navbarDropdown' role='button' data-bs-toggle='dropdown' data-bs-auto-close='outside'";
                }
                if ($changeLanguage && $item->slug == 'khmer') {
                    $str =
                        $str .
                        " <a class='nav-link' href='" .
                        url($slugLanguage) .
                        "'>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    <img src='" .
                        json_decode($item->param1)->khmer->file_icon .
                        "' alt='flag_khmer.png' width='20'> " .
                        $menuName .
                        '</a>';
                }
                if ($changeLanguage && $item->slug == 'english') {
                    $str = $str . " <a class='nav-link' href='" . $urlEn . "'> <img src='" . json_decode($item->param1)->english->file_icon . "' alt='flag_english.png' width='20'>" . $menuName . '</a>';
                }
                if ($hasExternalUrl && !$changeLanguage) {
                    $externalLink = $item->link;
                    $str = $str . " <a class='nav-link $aClass ' target='_blank' href='" . $externalLink . "'> " . $menuName . '</a>';
                }
                if (!$hasExternalUrl && !$changeLanguage) {
                    $slug = $item->slug;
                    if (App::getLocale() == 'en') {
                        $str = $str . " <a class='nav-link $aClass ' href='" . url('/') . '/' . 'en/' . $item->slug . "' $aDropdown> " . $menuName . '</a>';
                    } else {
                        $str = $str . " <a class='nav-link $aClass ' href='" . url('/') . '/' . $item->slug . "' $aDropdown> " . $menuName . '</a>';
                    }
                }
                if ($item->deeper) {
                    $str = $str . "<ul class='deeper dropend dropdown-menu drop-fade-down border-0 shadow' aria-labelledby='navbarDropdown'>";
                } elseif ($item->shallower) {
                    $str = $str . '</li>';
                    $str = $str . str_repeat('</ul></li>', $item->level_diff);
                } else {
                    $str = $str . '</li>';
                }
            }
            
            $str = $str . '<li>' . ($txtSearch = App::getLocale() == 'en' ? '' : '');
            '</li></ul>';
            
            $str =
                $str .
                "
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <li class='nav-item search'>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <a class='nav-link' role='button'  data-bs-toggle='modal' data-bs-target='#searchPopup'>                                                                                   <span class='material-symbols-outlined'>search</span><br>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                </a>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            </li>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        </ul>";
            echo $str;
            ?>

        </div>
    </div>

    <!-- 03 -->
    <div class="container-xl pt-3">
        <div class="row" style="height:50px">
            <?php
            $logo = '';
            $longitude = '';
            foreach ($menuFooterItems as $key => $value) {
                if ($value->key == 'logo') {
                    $logo = $value->image;
                }
                if ($value->key == 'longitude') {
                    $longitude = $value->image;
                }
            }
            ?>
            <div class="col-md-3 col-sm-12 p-0">
                <a href="<?php echo e(url(App::getLocale() == 'en' ? 'en' : '/')); ?>">
                    <img class="largeLogo" src="<?php echo e($logo); ?>" alt="AIS_Logo_Final-21.png"
                        style="width: 85%;background: #012642;">
                </a>
            </div>
            <div div class="col-md-9 col-sm-12 h-100">
                <nav class="navbar navbar-expand-lg navbar-light p-0 h-100">
                    <div class="container-xl p-0" style="border-radius: 4px 4px 0 0;">
                        <a class="navbar-brand" href="<?php echo e(url(App::getLocale() == 'kh' ? '/' : 'en')); ?>">
                            <img src="<?php echo e($longitude); ?>" alt="AIS_Logo_Final-21.png" style="height: 40px;">
                        </a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <!-- <div class="offcanvas offcanvas-start overflow-scroll" id="navbarSupportedContent"> -->
                        <!-- collapse navbar-collapse -->
                        <div id="navbarSupportedContent" class="collapse navbar-collapse">
                            <div class="offcanvas-header">
                                <a href="<?php echo e(url(App::getLocale() == 'kh' ? '/' : 'en')); ?>">
                                    <img src="<?php echo e($longitude); ?>" alt="AIS_Logo_Final-21.png" style="height: 40px;">
                                </a>
                                <button type="button" class="btn-close p-3" data-bs-dismiss="offcanvas"></button>
                            </div>
                            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 w-100 mobile-menu">

                                <?php
                                $str = "<ul class='navbar-nav mx-auto mb-2 mb-lg-0 w-100 mobile-menu'>";
                                foreach ($mainMenu as $i => $item) {
                                    $aClass = '';
                                    $aDropdown = '';
                                    $externalLink = '';
                                    $slug = '';
                                    $hasChild = $item->right - $item->left > 1;
                                    $hasExternalUrl = $item->link != null;
                                    $changeLanguage = $item->menu_type == 'change_language';
                                    $menuName = App::getLocale() == 'en' ? $item->menu_en : $item->menu_kh;
                                    $menuSlug = App::getLocale() == 'en' ? $item->slug : $item->slug;
                                    $urlEn = url('en/' . $slugLanguage);
                                    if ($slugLanguage == $menuName || $slugLanguage == $menuSlug) {
                                        $menuActive = 'active';
                                    } elseif (($slugLanguage == '/' || $slugLanguage == '/en') && $item->menu_type == 'main_page') {
                                        // if it's home
                                        $menuActive = 'active';
                                    } else {
                                        $menuActive = '';
                                    }
                                    $str = $str . "<li class='nav-item dropdown " . $menuActive . " '>";
                                    if ($hasChild) {
                                        $aClass = 'dropdown-toggle';
                                        $aDropdown = "id='navbarDropdown' role='button' data-bs-toggle='dropdown' data-bs-auto-close='outside'";
                                    }
                                    if ($changeLanguage && $item->slug == 'khmer') {
                                        $str = $str . " <a class='nav-link' href='" . url($slugLanguage) . "'> " . $menuName . '</a>';
                                    }
                                    if ($changeLanguage && $item->slug == 'english') {
                                        $str = $str . " <a class='nav-link' href='" . $urlEn . "'> " . $menuName . '</a>';
                                    }
                                    if ($hasExternalUrl && !$changeLanguage) {
                                        $externalLink = $item->link;
                                        $str = $str . " <a class='dropdown-item $aClass ' href='" . $externalLink . "' target='_blank'> " . $menuName . '</a>';
                                    }
                                    if (!$hasExternalUrl && !$changeLanguage) {
                                        $slug = $item->slug;
                                        if (App::getLocale() == 'en') {
                                            $str = $str . " <a class='dropdown-item $aClass ' href='" . url('/') . '/' . 'en/' . $item->slug . "' $aDropdown> " . $menuName . '</a>';
                                        } else {
                                            $str = $str . " <a class='dropdown-item $aClass ' href='" . url('/') . '/' . $item->slug . "' $aDropdown> " . $menuName . '</a>';
                                        }
                                    }
                                    if ($item->deeper) {
                                        $str = $str . "<ul class='deeper dropend dropdown-menu submenu drop-fade-up border-0 shadow' aria-labelledby='navbarDropdown'>";
                                    } elseif ($item->shallower) {
                                        $str = $str . '</li>';
                                        $str = $str . str_repeat('</ul></li>', $item->level_diff);
                                    } else {
                                        $str = $str . '</li>';
                                    }
                                }
                                $str = $str . '</ul>';
                                echo $str;
                                ?>

                                <?php
                                $str = "<ul class='navbar-nav mx-auto mb-2 mb-lg-0 w-100 mobile-menu displayNone'>";
                                foreach ($topMenu as $i => $item) {
                                    $aClass = '';
                                    $aDropdown = '';
                                    $externalLink = '';
                                    $slug = '';
                                    $hasChild = $item->right - $item->left > 1;
                                    $hasExternalUrl = $item->link != null;
                                    $changeLanguage = $item->menu_type == 'change_language';
                                    $menuName = App::getLocale() == 'en' ? $item->menu_en : $item->menu_kh;
                                    // $hasIconLanguage = ($item->param1 !='' && $item->menu_type == 'change_language');
                                    $urlEn = url('en/' . $slugLanguage);
                                    $str = $str . "<li class='nav-item'>";
                                
                                    if ($hasChild) {
                                        $aClass = 'dropdown-toggle';
                                        $aDropdown = "id='navbarDropdown' role='button' data-bs-toggle='dropdown' data-bs-auto-close='outside'";
                                    }
                                    if ($changeLanguage && $item->slug == 'khmer') {
                                        $str = $str . " <a class='dropdown-item' href='" . url($slugLanguage) . "'><img src='" . json_decode($item->param1)->khmer->file_icon . "' width='20'> " . $menuName . '</a>';
                                    }
                                    if ($changeLanguage && $item->slug == 'english') {
                                        $str = $str . " <a class='dropdown-item' href='" . $urlEn . "'> <img src='" . json_decode($item->param1)->english->file_icon . "' width='20'>" . $menuName . '</a>';
                                    }
                                    if ($hasExternalUrl && !$changeLanguage) {
                                        $externalLink = $item->link;
                                        $str = $str . " <a class='dropdown-item $aClass ' target='_blank' href='" . $externalLink . "'> " . $menuName . '</a>';
                                    }
                                    if (!$hasExternalUrl && !$changeLanguage) {
                                        $slug = $item->slug;
                                        if (App::getLocale() == 'en') {
                                            $str = $str . " <a class='dropdown-item $aClass ' href='" . url('/') . '/' . 'en/' . $item->slug . "' $aDropdown> " . $menuName . '</a>';
                                        } else {
                                            $str = $str . " <a class='dropdown-item $aClass ' href='" . url('/') . '/' . $item->slug . "' $aDropdown> " . $menuName . '</a>';
                                        }
                                    }
                                    if ($item->deeper) {
                                        $str = $str . "<ul class='deeper dropend dropdown-menu drop-fade-down border-0 shadow' aria-labelledby='navbarDropdown'>";
                                    } elseif ($item->shallower) {
                                        $str = $str . '</li>';
                                        $str = $str . str_repeat('</ul></li>', $item->level_diff);
                                    } else {
                                        $str = $str . '</li>';
                                    }
                                }
                                $str = $str . '</ul>';
                                echo $str;
                                ?>

                            </ul>
                        </div>
                    </div>
                </nav>
            </div>

        </div>
    </div>
</div>

<div class="modal fade search-popup" id="searchPopup" tabindex="-1" aria-labelledby="searchPopupLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <form class="menu-search my-4" action="<?php echo e(url(App::getLocale() == 'kh' ? 'search' : 'en/search')); ?>"
                    method="GET">
                    <input type="search" name="search" id="search"
                        placeholder="<?php echo e(App::getLocale() == 'en' ? 'Search' : 'ស្វែងរក'); ?>">
                    <button type="submit"
                        class="btn btn-sm btn-general btn-secondary-contained"><?php echo e(App::getLocale() == 'en' ? 'Search' : 'ស្វែងរក'); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(e) {
            $('li.active').parents('li').addClass('active');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\ais_ccv_website\resources\views/Cms/top-menu.blade.php ENDPATH**/ ?>