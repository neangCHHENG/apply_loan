<?php $__env->startSection('content'); ?>
    <!-- Carousel -->
    <section class="home">
        <div id="homeCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="500"
            data-bs-pause="false">
            <div class="carousel-indicators">
                <?php $__currentLoopData = $data['slide']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type='button' data-bs-target='#homeCarousel' data-bs-slide-to='<?php echo e($key); ?>'
                        class='<?php echo e($key == 0 ? 'active' : ''); ?>' aria-current='true' aria-label='Slide <?php echo e($key + 1); ?>'>
                        <div class='overlay-image' style='background-image: url("<?php echo e($value->thumbnail); ?>")'></div>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $data['slide']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>'
                        style='background-image: url("<?php echo e($value->thumbnail); ?>")'>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev mx-5" type="button" data-bs-target="#homeCarousel" data-bs-slide="prev">
                <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
                <i class="fa-solid fa-chevron-left"></i>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next mx-5" type="button" data-bs-target="#homeCarousel" data-bs-slide="next">
                <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
                <i class="fa-solid fa-chevron-right"></i>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>
    <!-- Caption -->
    <section class="home" style="margin:5% 0">
        <div class="container-xl p-5 text-center">
            <h2 class="fw-bold">
                <?php echo e(App::getLocale() == 'en' ? $data['ais']->value_en : $data['ais']->value_kh); ?></h2><br>
            <p>
                <?php echo e(App::getLocale() == 'en' ? $data['ais']->description_en : $data['ais']->description_kh); ?></p>
        </div>
    </section>
    <!-- Feature -->
    <section id="feature" class="feature">
        <div class="row">
            
            <?php $__currentLoopData = $data['feature']->articlefeature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-12 p-0" style="margin-bottom: 20px;">
                    <div class="card h-100">
                        <img class="card-img img-overlay" src="<?php echo e($value->thumbnail); ?>" alt="photo_2023-03-24_14-31-11.jpg">
                        <div class="card-img-overlay">
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingOne">
                                        <strong class="panel-title">
                                            <a class="text-uppercase" role="button" data-toggle="collapse"
                                                data-parent="#accordion" href="#collapseOne<?php echo e($key); ?>"
                                                aria-expanded="true" aria-controls="collapseOne<?php echo e($key); ?>"
                                                style="color:#fff; text-decoration: none;">
                                                <strong><?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?></strong>
                                            </a>
                                        </strong>
                                    </div>
                                    <div id="collapseOne<?php echo e($key); ?>" class="panel-collapse collapse"
                                        role="tabpanel" aria-labelledby="headingOne">
                                        <div class="panel-body">
                                            <?php echo e(App::getLocale() == 'en' ? $value->introduction_en : $value->introduction_kh); ?>

                                            <br> <br>
                                            <a class="read-more text-uppercase"
                                                href="<?php echo e(App::getLocale() == 'en' ? url('en/articles/' . $value->slug_en) : url('articles/' . $value->slug_en)); ?>"
                                                style="color:#fff;"><?php echo e(App::getLocale() == 'en' ? 'Read More' : 'អានបន្ត'); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </section>

    <!-- Video -->
    <section class="play-video">
        <div class="bg-overlay bg-parallax py-5">
            <h2 class="text-center fw-bold pb-5 wow animated fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
                <?php echo e(App::getLocale() == 'en' ? 'Optimal Enviroment' : 'បរិស្ថានល្អបំផុត'); ?>

            </h2>
            <div class="">
                <div id="homeCarouselVideo" class="carousel slide carousel-fade" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <?php $__currentLoopData = $data['videoEmbed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type='button' data-bs-target='#homeCarouselVideo'
                                data-bs-slide-to='<?php echo e($key); ?>' class='<?php echo e($key == 0 ? 'active' : ''); ?>'
                                aria-current='true' aria-label='Slide <?php echo e($key + 1); ?>' style="opacity: 0">
                                <div class='overlay-image' style='background-image: url("<?php echo e($value->thumbnail); ?>")'>
                                </div>
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $data['videoEmbed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class='carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>'>
                                <div class="container-xl">
                                    <div class="row">
                                        <div class="col-xl-6 col-md-6 py-3">
                                            <center class="description_video">
                                                <h5 class="fw-bold">
                                                    <?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?>

                                                </h5>
                                                <p>
                                                    <?php
                                                    if (App::getLocale() == 'en') {
                                                        echo $value->description_en;
                                                    } else {
                                                        echo $value->description_kh;
                                                    }
                                                    ?>
                                                </p>
                                                <a class="read-more-news read-more btn btn-lg" target="_blank"
                                                    href="<?php echo e($value ? $value->url : ''); ?>"><?php echo e(App::getLocale() == 'en' ? 'Watch the Video' : 'មើល​វីដេអូ'); ?></a>
                                            </center>

                                        </div>
                                        <div class="col-xl-6 col-md-6" style="position: relative;">
                                            <?php
                                            $url = '';
                                            $embedUrl = explode('=', $value->url);
                                            $url = $embedUrl[1];
                                            
                                            ?>
                                            <iframe class="img-fluid rounded-2"
                                                src="https://www.youtube.com/embed/<?php echo e($url); ?>"
                                                title="YouTube video player" frameborder="0"
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                allowfullscreen style="width: 100%;height: 350px;"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button class="carousel-control-prev mx-5" type="button" data-bs-target="#homeCarouselVideo"
                        data-bs-slide="prev">
                        <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
                        <i class="iconSlide fa-solid fa-chevron-left"></i>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next mx-5" type="button" data-bs-target="#homeCarouselVideo"
                        data-bs-slide="next">
                        <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
                        <i class="iconSlide fa-solid fa-chevron-right"></i>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </section>
    <section id="feature" class="feature">
        <div class="container-xl p-0 mt-5 text-center">
            <div class="row">
                <div class="col-md-6 col-sm-12 content-research p-5">
                    <h4>
                        <?php echo e(App::getLocale() == 'en' ? $data['experiment']->value_en : $data['experiment']->value_kh); ?>

                    </h4>
                    <p><?php echo e(App::getLocale() == 'en' ? $data['experiment']->description_en : $data['experiment']->description_kh); ?>

                    </p><br>
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <a class="research-link"
                                href="<?php echo e(App::getLocale() == 'en' ? url('en/articles/research-blog') : url('articles/research-blog')); ?>"><?php echo e(App::getLocale() == 'en' ? '1' : '១'); ?>

                            </a>

                            <p class="text-center"><?php echo e(App::getLocale() == 'en' ? 'Research Blog' : 'បណ្តុំស្រាវជ្រាវ'); ?>

                            </p>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <a class="research-link"
                                href="<?php echo e(App::getLocale() == 'en' ? url('en/articles/experiments') : url('articles/experiments')); ?>"><?php echo e(App::getLocale() == 'en' ? '2' : '២'); ?>

                            </a>

                            <p class="text-center"><?php echo e(App::getLocale() == 'en' ? 'Experiments' : 'ការធ្វើពិសោធន៍'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 p-0 m-0">
                    <div class="content-research-img content-research">
                        <img class="img-research" src="<?php echo e($data['experiment']->image); ?>"
                            alt="photo_2023-03-24_14-31-11.jpg">
                    </div>
                </div>
            </div><br><br>
            <div class="row">
                <div class="col-md-6 col-sm-12 p-0 m-0">
                    <div class="content-research-img" style="background: #095a9a;float: right;">
                        <img class="img-research-ml img-research" src="<?php echo e($data['researchProgram']->image); ?>"
                            alt="photo_2023-03-24_14-31-11.jpg">
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 content-research p-5" style="background: #095a9a;">
                    <h4>
                        <?php echo e(App::getLocale() == 'en' ? $data['researchProgram']->value_en : $data['researchProgram']->value_kh); ?>

                    </h4>
                    <p><?php echo e(App::getLocale() == 'en' ? $data['researchProgram']->description_en : $data['researchProgram']->description_kh); ?>

                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Student Life -->
    <section class="student-life">
        <div class="row" style="padding:5% 0">
            <div class="col-md-6 col-sm-12 text-center" style="margin: 0 auto">
                <h2 class="fw-bold">
                    <?php echo e(App::getLocale() == 'en' ? $data['ourCommitment']->value_en : $data['ourCommitment']->value_kh); ?>

                </h2>
                <br>
                <p><?php echo e(App::getLocale() == 'en' ? $data['ourCommitment']->description_en : $data['ourCommitment']->description_kh); ?>

                </p>
            </div>
        </div>
        <div class="container-xl p-0">
            <div class="row">
                <div class="owl-carousel owl-theme article__card" id="owl-carousel-student-life">
                    <?php $__currentLoopData = $data['student_life']->newsArticle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item mb-3 w-100">
                            <div class="card border-0 mb-3 w-100">
                                <div class="card h-100">
                                    
                                    
                                    <img class="card-img img-overlay h-100" src="<?php echo e($value->thumbnail); ?>"
                                        alt="photo_2023-03-24_14-31-11.jpg">
                                    <div class="title-ais">
                                        <p><strong>
                                                <?php echo e(Str::limit(App::getLocale() == 'en' ? $value->title_en : $value->title_kh, 50)); ?>

                                            </strong>
                                        </p>
                                        <p> <?php echo e(Str::limit(App::getLocale() == 'en' ? $value->introduction_en : $value->introduction_kh, 100)); ?>

                                        </p>
                                        <a class="read-more text-uppercase"
                                            href="<?php echo e(App::getLocale() == 'kh' ? url('articles/' . $value->slug_en) : url('en/articles/' . $value->slug_en)); ?>"
                                            style="color:#fff;"><?php echo e(App::getLocale() == 'en' ? 'Read More' : 'អានបន្ត'); ?>

                                        </a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- News -->
    <section class="event arrow_hidden pt-5" style="padding-bottom:5%">
        <div class="container-xl p-0"><br><br>
            <div class="title text-center p-5" style="color: #fff">
                <h2>
                    <?php echo e(App::getLocale() == 'en' ? 'School News' : 'ព័ត៌មានសាលា'); ?>

                </h2>
            </div>
            <div class="row">
                <div class="owl-carousel owl-theme article__card" id="owl-carousel-ais">
                    <?php $__currentLoopData = $data['schoolNews']->articleNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item mb-3 w-100">
                            <div class="card border-0 mb-3 w-100">
                                <div class="card h-100">
                                    <a href="<?php echo e(App::getLocale() == 'kh' ? url('articles/' . $value->slug_en) : url('en/articles/' . $value->slug_en)); ?>"
                                        style="text-decoration: none;">
                                        <?php if($value->thumbnail == null): ?>
                                            <img src="<?php echo e(asset('FrontEnd/Image/background/noimage.jpg')); ?>"
                                                class="card-img img-overlay">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset($value->thumbnail)); ?>" class="card-img img-overlay">
                                        <?php endif; ?>
                                        <div class="card-img-overlay m-0"
                                            style="bottom: auto;background: #f5f5f5; padding: 1.5rem!important;color:#212529;padding-top: 0.6rem !important;">
                                            <span
                                                style="font-size: 12px"><?php echo e(\Carbon\Carbon::parse($value->schedule)->format('M d, Y')); ?></span>
                                            <h4>
                                                <?php echo e(Str::limit(App::getLocale() == 'en' ? $value->title_en : $value->title_kh, 60)); ?>

                                            </h4>
                                            <p> <?php echo e(Str::limit(App::getLocale() == 'en' ? $value->introduction_en : $value->introduction_kh, 110)); ?>

                                            </p>
                                            <p class="btn-read-more">
                                                <?php echo e(App::getLocale() == 'en' ? 'Read More' : 'អានបន្ត'); ?>

                                            </p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <center><br><br>
                    <a class="read-more-news read-more btn btn-lg"
                        href="<?php echo e(App::getLocale() == 'kh' ? url('news') : url('en/news/')); ?>"><?php echo e(App::getLocale() == 'en' ? 'Other News' : 'ព័ត៌មានផ្សេងទៀត'); ?>

                    </a>
                </center>

            </div>
        </div>
    </section>

    <!-- Events -->
    <section class="events pb-5 pt-5">
        <div class="container-xl p-0">
            <div class="text-center p-5">
                <h2>
                    <?php echo e(App::getLocale() == 'en' ? 'School Events' : 'ព្រឹត្តិការណ៍សាលា'); ?>

                </h2>
            </div>
            <div class="news row">
                <?php $__currentLoopData = $data['eventSchool']->event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row col-md-6 col-sm-12 card-body">
                        <div class="p-2">
                            <div class="row" style="background: #003764;padding:15px;border-radius: 5px;">
                                <div class="col-md-2 col-sm-2" style="padding: 10px">
                                    <div class="date date-home">
                                        <time class="event-short-date" datetime="2023-05-15">

                                            <span class="day"
                                                style="font-size: 15px"><?php echo e(\Carbon\Carbon::parse($value->start_date)->format('M')); ?>

                                            </span>
                                            <span
                                                class="day"><?php echo e(\Carbon\Carbon::parse($value->start_date)->format('d')); ?>

                                            </span>
                                        </time>
                                    </div>
                                </div>
                                <div class="col-md-10 col-sm-10 m-0">
                                    <div class="info">
                                        <p style="font-weight: bold !important;">
                                            <?php echo e(Str::limit(App::getLocale() == 'en' ? $value->title_en : $value->title_kh, 200)); ?>

                                        </p>
                                        <span style="font-size: 12px">
                                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                                            <?php echo e(App::getLocale() == 'en' ? $value->date_en : $value->date_kh); ?></span>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <center><br><br>
                <a class="read-more-news read-more btn btn-lg"
                    href="<?php echo e(App::getLocale() == 'kh' ? url('school-event') : url('en/school-event/')); ?>"><?php echo e(App::getLocale() == 'en' ? 'Other Event' : 'ព្រឹត្តិ្កការណ៍ផ្សេងទៀត'); ?></a>
            </center>

        </div>

    </section>

    <!-- Campus -->
    <section class="campus pt-5 pb-5">
        <div class="container-xl p-0">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10 col-sm-12 text-center">
                    <h2 class="text-center fw-bold mb-5 color-dark-purple">
                        <?php echo e(App::getLocale() == 'en' ? 'Campus' : 'សាខា'); ?> </h2>
                </div>
            </div>
            <div class="row">
                <div class="owl-carousel owl-theme article__card" id="owl-carousel-campus">
                    <?php $__currentLoopData = $data['campus']->article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item mb-3 w-100">
                            <div class="campus card h-100">
                                <a href="<?php echo e($value->note); ?>" style="background:black;" target="_blank">
                                    <img class="card-img img-overlay" src="<?php echo e($value->thumbnail); ?>"
                                        style="height: 200px">
                                    <div class="card-img-overlay">
                                        <h4 style="color: #181f59;">
                                            <?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?>

                                        </h4>

                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section><br><br>


    <div class="popup" id="popup">
        <?php
        $path = explode('/', $data['popUp'] ? $data['popUp']->image : '');
        $nameImage = $path[count($path) - 1];
        ?>
        <div class="overlay"></div>
        <div class="popup_content">
            <a href="<?php echo e($data['popUp'] ? $data['popUp']->url : ''); ?>">
                <img src="<?php echo e($data['popUp'] ? $data['popUp']->image : ''); ?>" alt="<?php echo e($nameImage); ?>">
            </a>

            <div class="close_btn" onclick="closePopup()">&times;</div>
        </div>
    </div>
    <input type="hidden" id="popupValue" value="<?php echo e($data['popUp']); ?>" />
    <script>
        window.onload = function() {
            let popup = $('#popupValue').val();
            if (popup) {
                setTimeout(function() {
                    $("#popup").addClass("active");
                }, 10)
            }
        }

        function closePopup() {
            $("#popup").removeClass("active");
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ais_ccv_website\resources\views/Cms/home.blade.php ENDPATH**/ ?>