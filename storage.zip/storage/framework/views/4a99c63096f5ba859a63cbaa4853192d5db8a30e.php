<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <div class="wrapper">
            <div class="thumbnail">
                <img src="<?php echo e(asset('FrontEnd/Image/background/bg-015.jpg')); ?>">
            </div>
            <div class="container-xl content-title" style="max-width: 1096px;">
                <div class=" p-0">
                    <h2 class="text-white titleMJQE" style="text-shadow: 2px 2px #45454575;">
                        <?php echo e(App::getLocale() == 'en' ? 'Our Achievement' : ' ប្រវត្តិជោគជ័យ'); ?>

                    </h2>
                </div>
            </div>
        </div>
    </section>
    <div class="container-xl">
        <div class="row"
            style="margin-right: calc(var(--bs-gutter-x) * -.5); margin-left: calc(var(--bs-gutter-x) * -.5)">
            <div class="accordion accordion-flush" id="accordionFlushExample">
                <!-- blog -->
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?php echo e($key); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapse<?php echo e($key); ?>" aria-expanded="false"
                                aria-controls="collapse<?php echo e($key); ?>">
                                <?php echo e(App::getLocale() == 'en' ? $value->title_en : $value->title_kh); ?>

                            </button>
                        </h2>
                        <div id="collapse<?php echo e($key); ?>" class="accordion-collapse collapse"
                            aria-labelledby="heading<?php echo e($key); ?>" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">
                                <?php echo App::getLocale() == 'en' ? $value->description_en : $value->description_kh; ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <!-- blog -->
            </div>
            <nav aria-label="" class="d-flex justify-content-center">
                <?php echo e($data->links('pagination::bootstrap-4')); ?>

            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Cms.master-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ais_ccv_website\resources\views/Cms/event-list.blade.php ENDPATH**/ ?>