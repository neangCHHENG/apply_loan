<footer>
    <!-- Back to top button -->
    <a id="backToTopBtn">
        <i class="fa-solid fa-angle-up"></i>
    </a>
    <div class="container-fluid" style="background: #012642;">
        <div class="container-xl pt-5">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 px-0">
                    <ul style="display: grid;">
                        
                        <li class="mt-2">

                            <a href="<?php echo e(url(App::getLocale() == 'en' ? 'en' : '')); ?>">
                                <?php
                                $logo = '';
                                foreach ($menuFooterItems as $key => $value) {
                                    if ($value->key == 'logo') {
                                        $logo = $value->image;
                                    }
                                }
                                ?>
                                <img src="<?php echo e($logo); ?>" alt="AIS_Logo_Final-21.png" style="height: 100px;">
                            </a>
                        </li>

                        <?php
                        
                        foreach ($menuFooterItems as $menuFooterItem) {
                            if ($menuFooterItem->type == 'address' || $menuFooterItem->type == 'phone' || $menuFooterItem->type == 'email') {
                                $value = App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh;
                                $str = '';
                                echo $str = $str . '<ul><li>' . $value . '</li></ul>';
                            }
                        }
                        ?>

                    </ul>
                    <ul>

                        <ul class="icon-group">
                            <?php $__currentLoopData = $menuFooterItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menuFooterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($menuFooterItem->key == 'facebook'): ?>
                                    <li><a href="<?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>"
                                            target="_blank"><img src="<?php echo e($menuFooterItem->image); ?>" alt="icon"></a>
                                    </li>
                                <?php endif; ?>

                                <?php if($menuFooterItem->key == 'twitter'): ?>
                                    <li><a href="<?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>"
                                            target="_blank"><img src="<?php echo e($menuFooterItem->image); ?>" alt="icon"></a>
                                    </li>
                                <?php endif; ?>

                                <?php if($menuFooterItem->key == 'youtube'): ?>
                                    <li><a href="<?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>"
                                            target="_blank"><img src="<?php echo e($menuFooterItem->image); ?>" alt="icon"></a>
                                    </li>
                                <?php endif; ?>

                                <?php if($menuFooterItem->key == 'linkedin'): ?>
                                    <li><a href="<?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>"
                                            target="_blank"><img src="<?php echo e($menuFooterItem->image); ?>" alt="icon"></a>
                                    </li>
                                <?php endif; ?>

                                <?php if($menuFooterItem->key == 'tiktok'): ?>
                                    <li><a href="<?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>"
                                            target="_blank"><img src="<?php echo e($menuFooterItem->image); ?>" alt="icon"></a>
                                    </li>
                                <?php endif; ?>

                                <?php if($menuFooterItem->key == 'instagram'): ?>
                                    <li><a href="<?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>"
                                            target="_blank"><img src="<?php echo e($menuFooterItem->image); ?>" alt="icon"></a>
                                    </li>
                                <?php endif; ?>

                                <?php if($menuFooterItem->key == 'telegram'): ?>
                                    <li><a href="<?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>"
                                            target="_blank"><img src="<?php echo e($menuFooterItem->image); ?>" alt="icon"></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </ul>
                </div>
                
                <?php
                $countParent = null;
                $str = "<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12 menu-footer'> <ul>";
                foreach ($bottomMenu as $i => $item) {
                    $externalLink = '';
                    $aClass = '';
                    $lClass = '';
                    $hasChild = $item->right - $item->left > 1;
                    $hasExternalUrl = $item->link != null;
                    if ($item->level == 1) {
                        $countParent = $countParent + 1;
                    }
                    if (App::getLocale() == 'en') {
                        $menuName = $item->menu_en;
                        $language = 'en';
                    } else {
                        $menuName = $item->menu_kh;
                        $language = '';
                    }
                    if ($hasChild) {
                        $lClass = 'dropdown';
                        $aClass = 'footer dropdown-item dropdown-toggle';
                        $aDropdown = "id='navbarDropdown' role='button' data-bs-toggle='dropdown' data-bs-auto-close='outside'";
                    }
                    if ($countParent == 2) {
                        $str = $str . "</div> <div class='col-lg-4 col-md-4 col-sm-6 col-xs-12 px-0'> <ul>";
                        $countParent++;
                    }
                    $str = $str . "<li class='nav-item $lClass'>";
                    if ($hasExternalUrl) {
                        $externalLink = $item->link;
                        $str = $str . " <a class='$aClass' target='_blank' href='" . $externalLink . "'> " . $menuName . '</a>';
                    }
                    if (!$hasExternalUrl) {
                        $slug = $item->slug;
                        if ($item->level == 1) {
                            $str = $str . " <lable class='$aClass'> " . $menuName . '</lable>';
                        } else {
                            $str = $str . " <a class='$aClass' href='" . url('/') . '/' . $language . $item->slug . "'> " . $menuName . '</a>';
                        }
                    }
                    if ($item->deeper) {
                        $str = $str . '<ul>';
                    } elseif ($item->shallower) {
                        $str = $str . '</li>';
                        $str = $str . str_repeat('</ul></li>', $item->level_diff);
                    } else {
                        $str = $str . '</li>';
                    }
                }
                $str = $str . '</ul></div>';
                echo $str;
                ?>
                
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 px-0">
                    <ul style="display: grid;">
                        <li class="nav-item dropdown">
                            <label class="footer dropdown-item dropdown-toggle">
                                <?php
                                $str = '';
                                if (App::getLocale() == 'en') {
                                    $menuName = 'Visitors';
                                    $language = 'en';
                                } else {
                                    $menuName = 'អ្នកទស្សនា';
                                    $language = '';
                                }
                                echo $str = $str . $menuName;
                                ?>
                            </label>
                        </li>

                        <ul>
                            <li><i class="fa-solid fa-user"></i>
                                <?php echo e(App::getLocale() == 'en' ? 'Visit Today' : 'ទស្សនាថ្ងៃនេះ'); ?>:
                                <strong><?php echo e($countDate['day']); ?></strong>
                            </li>
                            <li><i class="fa-solid fa-user"></i>
                                <?php echo e(App::getLocale() == 'en' ? 'Visit Yesterday' : 'ទស្សនាពីម្សិលមិញ'); ?>:
                                <strong><?php echo e($countDate['yesterday']); ?></strong>
                            </li>
                            <li><i class="fa-solid fa-calendar-days"></i>
                                <?php echo e(App::getLocale() == 'en' ? 'This Month' : 'ទស្សនាខែនេះ'); ?>:
                                <strong><?php echo e($countDate['month']); ?></strong>
                            </li>
                            <li><i class="fa-solid fa-calendar-days"></i>
                                <?php echo e(App::getLocale() == 'en' ? 'This Year' : 'ទស្សនាឆ្នាំនេះ'); ?>:
                                <strong><?php echo e($countDate['year']); ?></strong>
                            </li>
                            <li><i class="fa-solid fa-calendar-days"></i>
                                <?php echo e(App::getLocale() == 'en' ? 'Total Visit' : 'ទស្សនាសរុប'); ?>:
                                <strong><?php echo e($countDate['all']); ?></strong>
                            </li><br>
                            <li>
                                <img src="<?php echo e(asset('FrontEnd/Image/Ais Logo/qrcode.svg')); ?>"
                                    alt="AIS_Logo_Final-21.png" style="height: 70px;">
                            </li>

                        </ul>
                    </ul>
                </div>
            </div>
            <div class="row"><br>

            </div>
        </div>
    </div>
    <div class="container-fluid copy-right">
        <div class="container-xl" style="border-top: 1px solid #ffffff4a;">

            <center>
                <div class="d-table py-3">

                    <?php $__currentLoopData = $menuFooterItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menuFooterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($menuFooterItem->key == 'copyright'): ?>
                            <p class='d-table-cell px-5'>
                                <?php echo date('Y'); ?>
                                <?php echo e(App::getLocale() == 'en' ? $menuFooterItem->value_en : $menuFooterItem->value_kh); ?>

                            </p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </center>
        </div>
    </div>
</footer>
<?php /**PATH D:\ais_ccv_website\resources\views/Cms/bottom-menu.blade.php ENDPATH**/ ?>